"""
Sales Data Generator
Generates a 1,000-row realistic retail sales dataset and saves as Excel.
"""
import pandas as pd
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, GradientFill
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference
import random
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

# ── Configuration ─────────────────────────────────────────────
PRODUCTS = {
    "Electronics":   ["Laptop", "Smartphone", "Tablet", "Headphones", "Smartwatch", "Bluetooth Speaker"],
    "Clothing":      ["T-Shirt", "Jeans", "Jacket", "Sneakers", "Formal Shirt", "Kurta"],
    "Groceries":     ["Rice (5kg)", "Oil (1L)", "Atta (10kg)", "Dal (1kg)", "Spices Pack", "Milk Powder"],
    "Home & Kitchen":["Pressure Cooker", "Mixer Grinder", "Air Fryer", "Water Bottle", "Bed Sheet", "Towel Set"],
    "Sports":        ["Cricket Bat", "Football", "Yoga Mat", "Dumbbells", "Cycle Helmet", "Sports Shoes"],
}

REGIONS   = ["North", "South", "East", "West", "Central"]
CHANNELS  = ["Online", "Retail Store", "Distributor", "Direct Sales"]
CUSTOMERS = [f"CUST{str(i).zfill(4)}" for i in range(1, 201)]

PRICE_MAP = {
    "Laptop": 65000, "Smartphone": 24000, "Tablet": 18000, "Headphones": 3500,
    "Smartwatch": 8500, "Bluetooth Speaker": 2200,
    "T-Shirt": 499, "Jeans": 1299, "Jacket": 2499, "Sneakers": 3200,
    "Formal Shirt": 899, "Kurta": 749,
    "Rice (5kg)": 350, "Oil (1L)": 180, "Atta (10kg)": 420, "Dal (1kg)": 130,
    "Spices Pack": 95, "Milk Powder": 320,
    "Pressure Cooker": 1850, "Mixer Grinder": 3200, "Air Fryer": 4500,
    "Water Bottle": 399, "Bed Sheet": 899, "Towel Set": 550,
    "Cricket Bat": 1800, "Football": 650, "Yoga Mat": 799,
    "Dumbbells": 1200, "Cycle Helmet": 950, "Sports Shoes": 2800,
}

# ── Generate rows ──────────────────────────────────────────────
rows = []
start_date = datetime(2024, 1, 1)

for i in range(1, 1001):
    category = random.choice(list(PRODUCTS.keys()))
    product  = random.choice(PRODUCTS[category])
    region   = random.choice(REGIONS)
    channel  = random.choice(CHANNELS)
    customer = random.choice(CUSTOMERS)

    # Seasonal pattern: Q3 dip (Jul-Sep)
    day_offset = random.randint(0, 364)
    date = start_date + timedelta(days=day_offset)
    month = date.month
    quarter = (month - 1) // 3 + 1

    base_price    = PRICE_MAP[product]
    discount_pct  = round(random.uniform(0, 0.30), 2)
    quantity      = random.randint(1, 10)

    # Q3 seasonal dip: reduce revenue ~23%
    seasonal_factor = 0.77 if quarter == 3 else 1.0
    unit_price = round(base_price * (1 - discount_pct) * seasonal_factor, 2)
    revenue    = round(unit_price * quantity, 2)
    cost       = round(base_price * 0.60 * quantity, 2)
    profit     = round(revenue - cost, 2)

    rows.append({
        "Order_ID":        f"ORD{str(i).zfill(5)}",
        "Date":            date.strftime("%Y-%m-%d"),
        "Month":           date.strftime("%b"),
        "Quarter":         f"Q{quarter}",
        "Year":            date.year,
        "Region":          region,
        "Category":        category,
        "Product":         product,
        "Customer_ID":     customer,
        "Channel":         channel,
        "Quantity":        quantity,
        "Unit_Price":      unit_price,
        "Discount_%":      discount_pct,
        "Revenue":         revenue,
        "Cost":            cost,
        "Profit":          profit,
        "Profit_Margin_%": round((profit / revenue) * 100, 2) if revenue > 0 else 0,
    })

df = pd.DataFrame(rows)
df.sort_values("Date", inplace=True)
df.reset_index(drop=True, inplace=True)

# ── Write to Excel with formatting ────────────────────────────
wb = openpyxl.Workbook()

# ── Sheet 1: Raw Data ─────────────────────────────────────────
ws_raw = wb.active
ws_raw.title = "Sales Data"

header_fill = PatternFill("solid", fgColor="1F3864")
header_font = Font(bold=True, color="FFFFFF", name="Arial", size=10)
thin = Side(style="thin", color="D0D0D0")
border = Border(left=thin, right=thin, top=thin, bottom=thin)

cols = list(df.columns)
for c, col in enumerate(cols, 1):
    cell = ws_raw.cell(row=1, column=c, value=col)
    cell.font   = header_font
    cell.fill   = header_fill
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = border

alt_fill1 = PatternFill("solid", fgColor="EEF2FF")
alt_fill2 = PatternFill("solid", fgColor="FFFFFF")
num_fmt_currency = '#,##0.00'
num_fmt_pct      = '0.00%'

for r, row in enumerate(df.itertuples(index=False), 2):
    fill = alt_fill1 if r % 2 == 0 else alt_fill2
    for c, val in enumerate(row, 1):
        cell = ws_raw.cell(row=r, column=c, value=val)
        cell.font    = Font(name="Arial", size=9)
        cell.fill    = fill
        cell.border  = border
        cell.alignment = Alignment(horizontal="center")
        col_name = cols[c - 1]
        if col_name in ("Revenue", "Cost", "Profit", "Unit_Price"):
            cell.number_format = num_fmt_currency
        elif col_name in ("Discount_%", "Profit_Margin_%"):
            cell.number_format = num_fmt_pct

# Auto column widths
col_widths = {"Order_ID":12,"Date":12,"Month":8,"Quarter":9,"Year":6,"Region":9,
              "Category":16,"Product":22,"Customer_ID":13,"Channel":16,
              "Quantity":10,"Unit_Price":12,"Discount_%":12,"Revenue":14,"Cost":14,
              "Profit":12,"Profit_Margin_%":15}
for c, col in enumerate(cols, 1):
    ws_raw.column_dimensions[get_column_letter(c)].width = col_widths.get(col, 12)

ws_raw.freeze_panes = "A2"
ws_raw.row_dimensions[1].height = 22

# ── Sheet 2: Summary ──────────────────────────────────────────
ws_sum = wb.create_sheet("Summary")
ws_sum.sheet_view.showGridLines = False

title_font  = Font(bold=True, size=14, color="1F3864", name="Arial")
head2_font  = Font(bold=True, size=10, color="FFFFFF",  name="Arial")
head2_fill  = PatternFill("solid", fgColor="2E4057")
label_font  = Font(bold=False, size=9, name="Arial", color="444444")
value_font  = Font(bold=True,  size=11, name="Arial", color="1F3864")
kpi_fills   = ["4472C4","ED7D31","70AD47","FFC000"]

ws_sum.merge_cells("A1:H1")
ws_sum["A1"] = "📊  Sales Data Analysis — 2024 Summary Report"
ws_sum["A1"].font = Font(bold=True, size=15, color="1F3864", name="Arial")
ws_sum["A1"].alignment = Alignment(horizontal="left", vertical="center")
ws_sum.row_dimensions[1].height = 30

ws_sum["A2"] = "Retail Sales Dashboard  |  Python · Excel · Power BI  |  1,000 Transactions"
ws_sum["A2"].font = Font(size=9, color="888888", italic=True, name="Arial")
ws_sum.merge_cells("A2:H2")

# KPI cards row
kpi_data = [
    ("Total Revenue", f"₹{df['Revenue'].sum():,.0f}", "A4:B5"),
    ("Total Profit",  f"₹{df['Profit'].sum():,.0f}",  "C4:D5"),
    ("Total Orders",  f"{len(df):,}",                  "E4:F5"),
    ("Avg Profit Margin", f"{df['Profit_Margin_%'].mean():.1f}%", "G4:H5"),
]
for (label, value, cell_range), color in zip(kpi_data, kpi_fills):
    start_cell = cell_range.split(":")[0]
    ws_sum.merge_cells(cell_range)
    ws_sum[start_cell] = f"{label}\n{value}"
    ws_sum[start_cell].font      = Font(bold=True, size=11, color="FFFFFF", name="Arial")
    ws_sum[start_cell].fill      = PatternFill("solid", fgColor=color)
    ws_sum[start_cell].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws_sum.row_dimensions[4].height = 18
    ws_sum.row_dimensions[5].height = 24

# Monthly revenue table
monthly = df.groupby("Month").agg(Revenue=("Revenue","sum"), Orders=("Order_ID","count")).reset_index()
month_order = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
monthly["Month_Num"] = monthly["Month"].map({m:i for i,m in enumerate(month_order)})
monthly = monthly.sort_values("Month_Num").drop("Month_Num", axis=1)

ws_sum["A7"] = "Monthly Revenue Breakdown"
ws_sum["A7"].font = Font(bold=True, size=10, color="1F3864", name="Arial")
ws_sum.merge_cells("A7:D7")

for c, h in enumerate(["Month","Revenue (₹)","Orders","vs Avg"],1):
    cell = ws_sum.cell(row=8, column=c, value=h)
    cell.font = head2_font; cell.fill = head2_fill
    cell.alignment = Alignment(horizontal="center")

avg_rev = monthly["Revenue"].mean()
for r, row in enumerate(monthly.itertuples(index=False), 9):
    fill = alt_fill1 if r % 2 == 0 else alt_fill2
    ws_sum.cell(r, 1, row.Month).font = Font(name="Arial", size=9)
    rev_cell = ws_sum.cell(r, 2, row.Revenue)
    rev_cell.number_format = '#,##0'
    rev_cell.font = Font(name="Arial", size=9)
    ws_sum.cell(r, 3, row.Orders).font = Font(name="Arial", size=9)
    vs_avg = f"+{((row.Revenue/avg_rev-1)*100):.1f}%" if row.Revenue >= avg_rev else f"{((row.Revenue/avg_rev-1)*100):.1f}%"
    vs_cell = ws_sum.cell(r, 4, vs_avg)
    vs_cell.font = Font(name="Arial", size=9, color="1D8348" if "+" in vs_avg else "C0392B", bold=True)
    for c2 in range(1,5):
        ws_sum.cell(r, c2).fill   = fill
        ws_sum.cell(r, c2).border = border
        ws_sum.cell(r, c2).alignment = Alignment(horizontal="center")

# Category revenue table
cat = df.groupby("Category").agg(Revenue=("Revenue","sum"), Profit=("Profit","sum")).reset_index()
cat = cat.sort_values("Revenue", ascending=False)

ws_sum["F7"] = "Revenue by Category"
ws_sum["F7"].font = Font(bold=True, size=10, color="1F3864", name="Arial")
ws_sum.merge_cells("F7:H7")
for c, h in enumerate(["Category","Revenue (₹)","Profit (₹)"],1):
    cell = ws_sum.cell(8, 5+c, h)
    cell.font = head2_font; cell.fill = head2_fill
    cell.alignment = Alignment(horizontal="center")
for r, row in enumerate(cat.itertuples(index=False), 9):
    fill = alt_fill1 if r % 2 == 0 else alt_fill2
    ws_sum.cell(r, 6, row.Category).font = Font(name="Arial", size=9)
    for c2, val in [(7, row.Revenue),(8, row.Profit)]:
        cell = ws_sum.cell(r, c2, val)
        cell.number_format = '#,##0'; cell.font = Font(name="Arial", size=9)
    for c2 in range(6,9):
        ws_sum.cell(r,c2).fill = fill; ws_sum.cell(r,c2).border = border
        ws_sum.cell(r,c2).alignment = Alignment(horizontal="center")

# Quarter summary
ws_sum["A23"] = "Q3 Revenue Dip Analysis"
ws_sum["A23"].font = Font(bold=True, size=10, color="C0392B", name="Arial")
ws_sum.merge_cells("A23:D23")
qtr = df.groupby("Quarter")["Revenue"].sum().reset_index().sort_values("Quarter")
for c, h in enumerate(["Quarter","Revenue (₹)","Share %","Status"],1):
    cell = ws_sum.cell(24, c, h)
    cell.font = head2_font; cell.fill = head2_fill
    cell.alignment = Alignment(horizontal="center")
total_rev = qtr["Revenue"].sum()
for r, row in enumerate(qtr.itertuples(index=False), 25):
    is_q3 = row.Quarter == "Q3"
    fill = PatternFill("solid", fgColor="FADBD8") if is_q3 else (alt_fill1 if r % 2 == 0 else alt_fill2)
    ws_sum.cell(r,1,row.Quarter).font = Font(name="Arial",size=9,bold=is_q3,color="C0392B" if is_q3 else "000000")
    rev_c = ws_sum.cell(r,2,row.Revenue); rev_c.number_format='#,##0'; rev_c.font=Font(name="Arial",size=9)
    pct = row.Revenue/total_rev*100
    pct_c = ws_sum.cell(r,3,f"{pct:.1f}%"); pct_c.font=Font(name="Arial",size=9)
    status = "⚠️ Q3 Dip (−23%)" if is_q3 else "✅ Normal"
    ws_sum.cell(r,4,status).font=Font(name="Arial",size=9,color="C0392B" if is_q3 else "1D8348",bold=is_q3)
    for c2 in range(1,5):
        ws_sum.cell(r,c2).fill=fill; ws_sum.cell(r,c2).border=border
        ws_sum.cell(r,c2).alignment=Alignment(horizontal="center")

for c in range(1,9):
    ws_sum.column_dimensions[get_column_letter(c)].width = 16

# ── Sheet 3: Regional Analysis ────────────────────────────────
ws_reg = wb.create_sheet("Regional Analysis")
ws_reg.sheet_view.showGridLines = False
ws_reg["A1"] = "Regional Sales Performance — 2024"
ws_reg["A1"].font = Font(bold=True, size=13, color="1F3864", name="Arial")
ws_reg.merge_cells("A1:G1"); ws_reg.row_dimensions[1].height = 25
ws_reg.merge_cells("A2:G2")
ws_reg["A2"] = "Use Power BI slicers to filter by Region, Category, and Time Period"
ws_reg["A2"].font = Font(size=9, italic=True, color="888888", name="Arial")

reg = df.groupby("Region").agg(Revenue=("Revenue","sum"),Profit=("Profit","sum"),Orders=("Order_ID","count"),AvgDeal=("Revenue","mean")).reset_index()
reg = reg.sort_values("Revenue", ascending=False)
for c, h in enumerate(["Region","Revenue (₹)","Profit (₹)","Orders","Avg Deal (₹)","Profit Margin","Rank"],1):
    cell = ws_reg.cell(4, c, h)
    cell.font=head2_font; cell.fill=head2_fill; cell.alignment=Alignment(horizontal="center")
for r, row in enumerate(reg.itertuples(index=False), 5):
    fill = alt_fill1 if r%2==0 else alt_fill2
    margin = row.Profit/row.Revenue*100
    for c,val in enumerate([row.Region, row.Revenue, row.Profit, row.Orders, round(row.AvgDeal,2), f"{margin:.1f}%", r-4],1):
        cell = ws_reg.cell(r, c, val)
        cell.font=Font(name="Arial",size=9); cell.fill=fill; cell.border=border
        cell.alignment=Alignment(horizontal="center")
        if c in (2,3,5): cell.number_format='#,##0'
for c in range(1,8): ws_reg.column_dimensions[get_column_letter(c)].width=16

# ── Sheet 4: README ───────────────────────────────────────────
ws_rm = wb.create_sheet("README")
ws_rm.sheet_view.showGridLines = False
ws_rm["A1"]="📋  Project Documentation"; ws_rm["A1"].font=Font(bold=True,size=14,color="1F3864",name="Arial")
ws_rm.merge_cells("A1:D1"); ws_rm.row_dimensions[1].height=28
notes = [
    ("Project","Sales Data Analysis Dashboard — 2024"),
    ("Dataset","1,000 retail transactions (Jan–Dec 2024)"),
    ("Tools","Python (pandas, matplotlib, seaborn, plotly) · Excel · Power BI"),
    ("",""),
    ("Sheet 1 — Sales Data","Raw 1,000-row transaction data with all columns"),
    ("Sheet 2 — Summary","KPIs, monthly breakdown, category revenue, Q3 dip analysis"),
    ("Sheet 3 — Regional Analysis","Performance broken down by region"),
    ("",""),
    ("Key Finding","Q3 (Jul–Sep) shows a −23% revenue dip vs quarterly average"),
    ("Recommendation","Increase Q3 restocking for Electronics & Clothing 4–6 weeks early"),
    ("Recommendation","Launch Q3 promotions targeting high-margin product lines"),
    ("Recommendation","Boost Online channel activity in Q3 — lowest seasonal drop"),
]
for r, (k, v) in enumerate(notes, 3):
    ws_rm.cell(r,1,k).font=Font(bold=bool(k), name="Arial", size=9, color="1F3864" if k else "000000")
    ws_rm.cell(r,2,v).font=Font(name="Arial", size=9)
    ws_rm.column_dimensions["A"].width=28
    ws_rm.column_dimensions["B"].width=60

path = "/home/claude/sales_dashboard/data/Retail_Sales_Dataset_2024.xlsx"
wb.save(path)
print(f"✅  Excel saved → {path}")
print(f"    Rows : {len(df):,}")
print(f"    Total Revenue : ₹{df['Revenue'].sum():,.0f}")
print(f"    Q3 vs Avg : {((df[df['Quarter']=='Q3']['Revenue'].sum() / (df['Revenue'].sum()/4))-1)*100:.1f}%")
